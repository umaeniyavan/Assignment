package assignment;
import static org.junit.Assert.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
					
import org.junit.Test;		


public class UnitTesting {				

    @Test
    public void testAssert() throws IOException
    {
    	
    	String file1 = "input.txt";
        String file2 = "output.txt";
        assertEquals(Files.readString(Paths.get(file1)), Files.readString(Paths.get(file2)) );
        			
    }

	
}		

