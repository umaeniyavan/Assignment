package assignment;

import org.apache.commons.csv.*;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CSVFileParse {
    public static void main(String[] args) {
        String inputCsvFile = "C:\\Users\\Dell\\eclipse-workspace\\helloworld\\src\\assignment\\input.csv";
        String outputCsvFile = "C:\\Users\\Dell\\eclipse-workspace\\helloworld\\src\\assignment\\output.csv";
        String[] columnsToSort = {"Name", "City"}; // Array of column names to sort

        try {
            // Read the input CSV file
            FileReader fileReader = new FileReader(inputCsvFile);
            CSVParser csvParser = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(fileReader);

            // Get the words from the specified columns
            List<String> words = new ArrayList<>();
            for (CSVRecord record : csvParser) {
                for (String column : columnsToSort) {
                    String word = record.get(column);
                    words.add(word);
                }
            }

            // Sort the words in ascending order
            Collections.sort(words);

            // Write the sorted values to the output CSV file
            FileWriter fileWriter = new FileWriter(outputCsvFile);
            CSVPrinter csvPrinter = CSVFormat.DEFAULT.withHeader(columnsToSort).print(fileWriter);
            for (int i = 0; i < words.size(); i += columnsToSort.length) {
                csvPrinter.printRecord(words.subList(i, i + columnsToSort.length));
            }
            csvPrinter.flush();
            csvPrinter.close();

            System.out.println("Sorting completed. Sorted values are written to " + outputCsvFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
